(function(){
  if (window.__qntm_exec_runner_installed) return;
  window.__qntm_exec_runner_installed = true;
})();
