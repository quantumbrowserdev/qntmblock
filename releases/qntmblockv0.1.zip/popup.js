document.addEventListener('DOMContentLoaded', () => {
    const a = typeof browser === 'undefined' ? chrome : browser;

    const muteEnabled = document.getElementById('mute-enabled');
    const speedEnabled = document.getElementById('speed-enabled');
    const blurIntensity = document.getElementById('blur-intensity');
    const blurValue = document.getElementById('blur-value');
    const speedMultiplier = document.getElementById('speed-multiplier');
    const speedValue = document.getElementById('speed-value');
    const betaDetectionEnabled = document.getElementById('beta-detection-enabled');

    function updateBlurText(value) {
        blurValue.textContent = `${value}px`;
    }

    function updateSpeedText(value) {
        speedValue.textContent = `${value}x`;
    }

    function saveOptions() {
        const settings = {
            muteEnabled: muteEnabled.checked,
            blurIntensity: parseInt(blurIntensity.value, 10),
            blurEnabled: parseInt(blurIntensity.value, 10) > 0,
            speedEnabled: speedEnabled.checked,
            speedMultiplier: parseInt(speedMultiplier.value, 10),
            betaDetectionEnabled: betaDetectionEnabled.checked,
        };
        a.storage.sync.set(settings);
    }

    function restoreOptions() {
        const defaults = { 
            muteEnabled: true, 
            speedEnabled: true,
            blurIntensity: 10, 
            speedMultiplier: 16,
            betaDetectionEnabled: false,
        };
        a.storage.sync.get(defaults, (items) => {
            muteEnabled.checked = items.muteEnabled;
            speedEnabled.checked = items.speedEnabled;
            blurIntensity.value = items.blurIntensity;
            updateBlurText(items.blurIntensity);
            speedMultiplier.value = items.speedMultiplier;
            updateSpeedText(items.speedMultiplier);
            betaDetectionEnabled.checked = items.betaDetectionEnabled;
        });
    }

    restoreOptions();

    muteEnabled.addEventListener('change', saveOptions);
    speedEnabled.addEventListener('change', saveOptions);
    blurIntensity.addEventListener('change', saveOptions);
    speedMultiplier.addEventListener('change', saveOptions);
    betaDetectionEnabled.addEventListener('change', saveOptions);

    blurIntensity.addEventListener('input', () => updateBlurText(blurIntensity.value));
    speedMultiplier.addEventListener('input', () => updateSpeedText(speedMultiplier.value));
});