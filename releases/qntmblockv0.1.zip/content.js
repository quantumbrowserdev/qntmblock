const a = typeof browser === 'undefined' ? chrome : browser;

let settings = {
  blurEnabled: true,
  blurIntensity: 10,
  speedEnabled: true,
  speedMultiplier: 16, 
  muteEnabled: true,
  betaDetectionEnabled: false
};

const PLAYER_SELECTOR = '#movie_player';
const AD_CLASS = 'ad-showing';
const VIDEO_SELECTOR = '.html5-main-video';
const VIDEO_CONTAINER_SELECTOR = '.html5-video-container';
const AD_CONFIRMATION_SELECTORS = [
  '.ytp-ad-text',
  '.ytp-ad-preview-container'
];
const COSMETIC_AD_SELECTORS = [
  'ytd-ad-slot-renderer',
  'ytd-promoted-sparkles-text-search-renderer',
  'ytd-promoted-video-renderer',
  'div#player-ads',
  'ytd-engagement-panel-section-list-renderer[target-id="engagement-panel-ads"]',
  'ytd-merch-shelf-renderer',
  '#donation-shelf',
  '#ticket-shelf',
  'ytd-brand-video-singleton-renderer',
  'ytd-brand-video-shelf-renderer'
];

const styleTag = document.createElement('style');
styleTag.id = 'qntmblock-styles';
document.head.appendChild(styleTag);

function updateStylesheet() {
  let rules = '';
  if (settings.blurEnabled && settings.blurIntensity > 0) {
    const allSelectors = [
        ...COSMETIC_AD_SELECTORS,
        `${PLAYER_SELECTOR}.${AD_CLASS} ${VIDEO_CONTAINER_SELECTOR}`
    ].join(',\n');

    rules = `
      ${allSelectors} {
        filter: blur(${settings.blurIntensity}px) !important;
        pointer-events: none !important;
      }
    `;
  }
  styleTag.textContent = rules;
}

a.storage.sync.get(settings, (loadedSettings) => {
  Object.assign(settings, loadedSettings);
  updateStylesheet();
  initialize();
});

a.storage.onChanged.addListener((changes) => {
  let needsUiUpdate = false;
  for (const [key, { newValue }] of Object.entries(changes)) {
    if (settings.hasOwnProperty(key)) {
      settings[key] = newValue;
      needsUiUpdate = true;
    }
  }
  if (needsUiUpdate) {
    updateStylesheet();
    initialize();
  }
});

let isAdActive = false;
let originalPlaybackRate = 1;
let originalMutedState = false;

function applyAdEffects(player) {
  const video = player.querySelector(VIDEO_SELECTOR);
  if (video) {
    if (settings.muteEnabled) {
      video.muted = true;
    }
    if (settings.speedEnabled) {
      video.playbackRate = settings.speedMultiplier;
    }
  }
}

function startAdHandler(player) {
  if (isAdActive) return;
  isAdActive = true;

  const video = player.querySelector(VIDEO_SELECTOR);
  if (video) {
    originalPlaybackRate = video.playbackRate;
    originalMutedState = video.muted;
  }
  
  applyAdEffects(player);
  skipAdObserver.observe(player, { childList: true, subtree: true });
  skipAd();
}

function stopAdHandler() {
  if (!isAdActive) return;
  isAdActive = false;

  skipAdObserver.disconnect();

  const video = document.querySelector(VIDEO_SELECTOR);
  if (video) {
    video.playbackRate = originalPlaybackRate;
    video.muted = originalMutedState;
  }
}

function skipAd() {
  const skipButton = document.querySelector('.ytp-ad-skip-button-modern, .ytp-ad-skip-button');
  if (skipButton) skipButton.click();
}

let lastVideoTime = 0;
let timeUpdateInterval = null;

function betaAdDetection(player) {
    if (!settings.betaDetectionEnabled) return;

    const video = player.querySelector(VIDEO_SELECTOR);
    if (!video) return;

    const currentTime = video.currentTime;
    const adDurationThreshold = 45; 

    if (
        !isAdActive &&
        currentTime < lastVideoTime &&
        lastVideoTime > 1 &&
        video.duration > 0 &&
        video.duration < adDurationThreshold
    ) {
        startAdHandler(player);
    }

    lastVideoTime = currentTime;
}

const skipAdObserver = new MutationObserver(() => {
    skipAd();
});

function isAdShowing(player) {
  if (player.classList.contains(AD_CLASS)) {
    return true;
  }
  for (const selector of AD_CONFIRMATION_SELECTORS) {
    const video = player.querySelector(VIDEO_SELECTOR);
    if (video && player.querySelector(selector)) {
      return true;
    }
  }
  return false;
}

const videoAdObserver = new MutationObserver((mutations) => {
  for (const mutation of mutations) {
    const player = mutation.target.closest(PLAYER_SELECTOR);
    if (player) {
        if (isAdShowing(player)) {
            startAdHandler(player);
        } else {
            stopAdHandler();
        }
    }
  }
});

function initialize() {
  const player = document.querySelector(PLAYER_SELECTOR);
  if (timeUpdateInterval) clearInterval(timeUpdateInterval);

  if (player) {
    videoAdObserver.observe(player, { childList: true, subtree: true, attributes: true, attributeFilter: ['class'] });
    
    if (settings.betaDetectionEnabled) {
        timeUpdateInterval = setInterval(() => betaAdDetection(player), 100);
    }

    if (isAdShowing(player)) {
      startAdHandler(player);
    }
  } else {
    setTimeout(initialize, 500);
  }

}
