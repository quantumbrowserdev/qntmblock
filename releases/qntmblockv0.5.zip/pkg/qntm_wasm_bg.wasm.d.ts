/* tslint:disable */
/* eslint-disable */
export const memory: WebAssembly.Memory;
export const start: () => void;
export const compute_speed: (a: number, b: number, c: number) => number;
export const is_ad_time_wrap: (a: number, b: number, c: number, d: number) => number;
export const avg_u8: (a: any) => number;
export const compute_legit_speed: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
export const volume_fade_step: (a: number, b: number) => number;
export const evaluate_low_audio_ad: (a: number, b: number, c: number, d: number) => number;
export const __wbindgen_export_0: WebAssembly.Table;
export const __wbindgen_start: () => void;
