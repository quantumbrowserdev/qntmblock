/* tslint:disable */
/* eslint-disable */
export function start(): void;
export function compute_speed(legit: boolean, _randomize: boolean, multiplier: number): number;
export function is_ad_time_wrap(last_time: number, current_time: number, duration: number, threshold: number): boolean;
export function avg_u8(data: Uint8Array): number;
export function compute_legit_speed(legit: boolean, randomize: boolean, multiplier: number, legit_min: number, legit_max: number, legit_base: number): number;
export function volume_fade_step(current_volume: number, steps: number): number;
export function evaluate_low_audio_ad(avg_amp: number, duration: number, max_ad_duration: number, amp_threshold: number): boolean;

export type InitInput = RequestInfo | URL | Response | BufferSource | WebAssembly.Module;

export interface InitOutput {
  readonly memory: WebAssembly.Memory;
  readonly start: () => void;
  readonly compute_speed: (a: number, b: number, c: number) => number;
  readonly is_ad_time_wrap: (a: number, b: number, c: number, d: number) => number;
  readonly avg_u8: (a: any) => number;
  readonly compute_legit_speed: (a: number, b: number, c: number, d: number, e: number, f: number) => number;
  readonly volume_fade_step: (a: number, b: number) => number;
  readonly evaluate_low_audio_ad: (a: number, b: number, c: number, d: number) => number;
  readonly __wbindgen_export_0: WebAssembly.Table;
  readonly __wbindgen_start: () => void;
}

export type SyncInitInput = BufferSource | WebAssembly.Module;
/**
* Instantiates the given `module`, which can either be bytes or
* a precompiled `WebAssembly.Module`.
*
* @param {{ module: SyncInitInput }} module - Passing `SyncInitInput` directly is deprecated.
*
* @returns {InitOutput}
*/
export function initSync(module: { module: SyncInitInput } | SyncInitInput): InitOutput;

/**
* If `module_or_path` is {RequestInfo} or {URL}, makes a request and
* for everything else, calls `WebAssembly.instantiate` directly.
*
* @param {{ module_or_path: InitInput | Promise<InitInput> }} module_or_path - Passing `InitInput` directly is deprecated.
*
* @returns {Promise<InitOutput>}
*/
export default function __wbg_init (module_or_path?: { module_or_path: InitInput | Promise<InitInput> } | InitInput | Promise<InitInput>): Promise<InitOutput>;
